export class Contact {
  froms: string;
  message: string;
  subject: string;
}
