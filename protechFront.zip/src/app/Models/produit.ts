export class Produit{
  _id: string;
  nom: string;
  prix: number;
  desc: string;
  image: string;
  stock: number;
  sousCategorie: string;

  constructor() {
  }
}
