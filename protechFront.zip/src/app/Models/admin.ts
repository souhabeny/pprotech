export class Admin{
  _id: string;
  password: string;
  email: string;
  constructor() {
  }
}
