export class Categorie {
  _id: string;
  nom: string;
  image: string;

  constructor() {
  }
}
