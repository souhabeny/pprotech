export class SousCategorie{
  _id: string;
  nom: string;
  categorie: string;

  constructor() {
  }
}
