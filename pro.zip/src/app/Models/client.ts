export class Client{
  _id: string;
  nom: string;
  prenom: string;
  email: string;
  password: string;
  adresse: string;

  constructor() {
  }
}
